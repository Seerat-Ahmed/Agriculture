let cloudinary = require('cloudinary');
cloudinary.config({
    cloud_name: 'chennalhere',
    api_key: '566774652321121',
    api_secret: 'jkn_-YNtTxN39rdAv_j6xR0Z-oE',
});

module.exports = cloudinary;